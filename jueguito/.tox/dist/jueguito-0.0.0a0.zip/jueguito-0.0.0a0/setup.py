#!/usr/bin/env python
"""
<Author>


<Start Date>
    29 Oct 2021

<Description>
    Deployment script for the pldapi standalone application

<Usage>

    Refer to the documentation hosted at [redacted] for
    instructions on how to use this file

"""
from setuptools import setup

setup(
    name="jueguito",
    version="0.0.0a",
    author="",
    author_email="",
    description=(""),
    packages=["jueguito"],
    install_requires=[],
)
